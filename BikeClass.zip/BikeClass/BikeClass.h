/*
BikeClass.h - Library for smart lighting in bikes

Created by David alias Dastmema(Candy), 2019
*/

#ifndef BikeClass_h
#define BikeClass_h

#include "Arduino.h"

class Bike{
  public:
    Bike(int lBrakePin, int rBrakePin, int controlPin, int led[]);
    void begin();
  private:
    int _leftBrake;
    int _rightBrake;
    int _control;

    /*
     * 0 -> Left
     * 1 -> Center
     * 2 -> Right
    */
    int _front[3];
    int _back[3];
};

#endif