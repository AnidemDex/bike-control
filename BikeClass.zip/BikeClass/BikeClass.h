/*
BikeClass.h - Library for smart lighting in bikes

Created by David alias Dastmema(Candy), 2019
*/

#ifndef BikeClass_h
#define BikeClass_h

#include "Arduino.h"

class Bike{
  public:
    Bike(int lBrakePin, int rBrakePin, int controlPin, int frontLed[], int backLed[]);

    void begin();
    void turnOn(int light);
    void turnOn(int light[]);
    void turnOff(int light);
    void turnOff(int light[]);

    bool controlPinHasChanged();
    bool getControlState();

    int frontLight;
    int frontRightLight;
    int frontLeftLight;
    
    int backLight;
    int backLeftLight;
    int backRightLight;
    
  private:
    int _leftBrake;
    int _rightBrake;
    int _control;

    bool _controlState;
    bool _leftBrakeState;
    bool _rightBrakeState;

    bool _lastControlState;
    bool _lastLeftBrakeState;
    bool _lastRightBrakeState;

    /*
     * 0 -> Left
     * 1 -> Center
     * 2 -> Right
    */
    int _front[3];
    int _back[3];
};

#endif