/*
BikeClass.cpp - Library for smart lighting in bikes

Created by David alias Dastmema(Candy), 2019
*/
#include "Arduino.h"
#include "BikeClass.h"
Bike::Bike(int lBrakePin, int rBrakePin, int controlPin, int frontLed[], int backLed[])
{
  _leftBrake = lBrakePin;
  _rightBrake = rBrakePin;
  _control = controlPin;

  for(int i=0;i<3;i++){
    _front[i] = front_led[i];
  }

  frontLight = front_led[1];
  frontLeftLight = front_led[0];
  frontRightLight = front_led[2];

  for(int i=0;i<3;i++){
    _back[i] = back_led[i];
  }

  backLight = back_led[1];
  backLeftLight = back_led[0];
  backRightLight = back_led[2];

  _controlState = false;
  _leftBrakeState = false;
  _rightBrakeState = false;
  _lastControlState = false;
  _lastLeftBrakeState = false;
  _lastRightBrakeState = false;
}


void Bike::begin()
{
  pinMode(_leftBrake, INPUT);
  pinMode(_rightBrake, INPUT);
  pinMode(_control, INPUT);
  
  for(int i=0;i<3;i++){
    pinMode(_front[i], OUTPUT);
    pinMode(_back[i], OUTPUT);
  }
}

void Bike::turnOn(int light)
{
  if (getControlState() == HIGH)
  {
    digitalWrite(light, HIGH);
  }
}

void Bike::turnOn(int light[])
{
  // volatile
  int size = sizeof(light)/sizeof(*light);

  if (getControlState() == HIGH){
    for(int n = 0; n < size; n++)
    {
      digitalWrite(light[n], HIGH)
    }
  }
}

void Bike::turnOff(int light)
{
  digitalWrite(light, LOW);
}

void Bike::turnOff(int light[])
{
  // volatile
  int size = sizeof(light)/sizeof(*light);
  
  for(int n = 0; n < size; n++)
  {
    digitalWrite(light[n], HIGH)
  }
}

bool Bike::getControlState()
{
  return _lastControlState;
}

bool Bike::controlHasChanged()
{
  _controlState = digitalRead(_control) == HIGH;

  if (_controlState != _lastControlState)
  {
    _lastControlState = _controlState;
    return true;
  }
  else
  {
    _lastControlState = _controlState;
    return false;
  }
  
}