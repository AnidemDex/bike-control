/*
BikeClass.cpp - Library for smart lighting in bikes

Created by David alias Dastmema(Candy), 2019
*/
#include "Arduino.h"
#include "BikeClass.h"
Bike::Bike(int lBrakePin, int rBrakePin, int controlPin, int led[]){
      _leftBrake = lBrakePin;
      _rightBrake = rBrakePin;
      _control = controlPin;

      for(int i=0;i<3;i++){
        _front[i] = led[i];
      }

      for(int i=0;i<3;i++){
        _back[i] = led[i];
      }
    }

void Bike::begin(){
  pinMode(_leftBrake, INPUT);
  pinMode(_rightBrake, INPUT);
  pinMode(_control, INPUT);
  
  for(int i=0;i<3;i++){
    pinMode(_front[i], OUTPUT);
    pinMode(_back[i], OUTPUT);
  }
}